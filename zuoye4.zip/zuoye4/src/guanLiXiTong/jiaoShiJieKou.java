package guanLiXiTong;

public interface jiaoShiJieKou {
    void faFangXinShui(int xs); //发放薪水
}